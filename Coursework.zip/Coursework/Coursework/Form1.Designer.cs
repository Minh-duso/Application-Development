﻿namespace Coursework
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtInputString = new TextBox();
            label1 = new Label();
            txtNValue = new TextBox();
            label2 = new Label();
            label3 = new Label();
            txtResult = new TextBox();
            btnPrint = new Button();
            btnEncode = new Button();
            btnInputASCII = new Button();
            btnOutputASCII = new Button();
            btnSort = new Button();
            btnReset = new Button();
            btnDecode = new Button();
            btnHash = new Button();
            SuspendLayout();
            // 
            // txtInputString
            // 
            txtInputString.Font = new Font("Segoe UI", 13F);
            txtInputString.Location = new Point(276, 12);
            txtInputString.Name = "txtInputString";
            txtInputString.Size = new Size(205, 31);
            txtInputString.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15F);
            label1.Location = new Point(41, 9);
            label1.Name = "label1";
            label1.Size = new Size(184, 28);
            label1.TabIndex = 1;
            label1.Text = "Enter the String (S) :";
            // 
            // txtNValue
            // 
            txtNValue.Font = new Font("Segoe UI", 13F);
            txtNValue.Location = new Point(275, 78);
            txtNValue.Name = "txtNValue";
            txtNValue.Size = new Size(206, 31);
            txtNValue.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15F);
            label2.Location = new Point(41, 67);
            label2.Name = "label2";
            label2.Size = new Size(208, 28);
            label2.TabIndex = 3;
            label2.Text = "Enter the Number (N) :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 15F);
            label3.Location = new Point(12, 169);
            label3.Name = "label3";
            label3.Size = new Size(109, 28);
            label3.TabIndex = 5;
            label3.Text = "The Result :";
            // 
            // txtResult
            // 
            txtResult.Font = new Font("Segoe UI", 20F);
            txtResult.Location = new Point(127, 159);
            txtResult.Name = "txtResult";
            txtResult.Size = new Size(672, 43);
            txtResult.TabIndex = 6;
            // 
            // btnPrint
            // 
            btnPrint.Font = new Font("Segoe UI", 17F);
            btnPrint.Location = new Point(313, 115);
            btnPrint.Name = "btnPrint";
            btnPrint.Size = new Size(127, 38);
            btnPrint.TabIndex = 7;
            btnPrint.Text = "Print";
            btnPrint.UseVisualStyleBackColor = true;
            btnPrint.Click += btnPrint_Click;
            // 
            // btnEncode
            // 
            btnEncode.Font = new Font("Segoe UI", 17F);
            btnEncode.Location = new Point(12, 226);
            btnEncode.Name = "btnEncode";
            btnEncode.Size = new Size(127, 38);
            btnEncode.TabIndex = 8;
            btnEncode.Text = "Encode";
            btnEncode.UseVisualStyleBackColor = true;
            btnEncode.Click += btnEncode_Click;
            // 
            // btnInputASCII
            // 
            btnInputASCII.Font = new Font("Segoe UI", 17F);
            btnInputASCII.Location = new Point(145, 226);
            btnInputASCII.Name = "btnInputASCII";
            btnInputASCII.Size = new Size(233, 38);
            btnInputASCII.TabIndex = 9;
            btnInputASCII.Text = "Input ASCII Codes";
            btnInputASCII.UseVisualStyleBackColor = true;
            btnInputASCII.Click += btnInputASCII_Click;
            // 
            // btnOutputASCII
            // 
            btnOutputASCII.Font = new Font("Segoe UI", 17F);
            btnOutputASCII.Location = new Point(381, 226);
            btnOutputASCII.Name = "btnOutputASCII";
            btnOutputASCII.Size = new Size(225, 38);
            btnOutputASCII.TabIndex = 10;
            btnOutputASCII.Text = "Output ASCII Codes";
            btnOutputASCII.UseVisualStyleBackColor = true;
            btnOutputASCII.Click += btnOutputASCII_Click;
            // 
            // btnSort
            // 
            btnSort.Font = new Font("Segoe UI", 17F);
            btnSort.Location = new Point(807, 163);
            btnSort.Name = "btnSort";
            btnSort.Size = new Size(127, 38);
            btnSort.TabIndex = 11;
            btnSort.Text = "Sort";
            btnSort.UseVisualStyleBackColor = true;
            btnSort.Click += btnSort_Click;
            // 
            // btnReset
            // 
            btnReset.Font = new Font("Segoe UI", 17F);
            btnReset.Location = new Point(632, 46);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(127, 38);
            btnReset.TabIndex = 12;
            btnReset.Text = "Reset";
            btnReset.UseVisualStyleBackColor = true;
            btnReset.Click += btnReset_Click;
            // 
            // btnDecode
            // 
            btnDecode.Font = new Font("Segoe UI", 17F);
            btnDecode.Location = new Point(745, 226);
            btnDecode.Name = "btnDecode";
            btnDecode.Size = new Size(127, 38);
            btnDecode.TabIndex = 8;
            btnDecode.Text = "Decode";
            btnDecode.UseVisualStyleBackColor = true;
            btnDecode.Click += btnDecode_Click;
            // 
            // btnHash
            // 
            btnHash.BackColor = SystemColors.ButtonHighlight;
            btnHash.Font = new Font("Segoe UI", 17F);
            btnHash.Location = new Point(612, 226);
            btnHash.Name = "btnHash";
            btnHash.Size = new Size(127, 38);
            btnHash.TabIndex = 13;
            btnHash.Text = "Hash";
            btnHash.UseVisualStyleBackColor = false;
            btnHash.Click += btnHash_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Info;
            ClientSize = new Size(946, 334);
            Controls.Add(btnHash);
            Controls.Add(btnDecode);
            Controls.Add(btnReset);
            Controls.Add(btnSort);
            Controls.Add(btnOutputASCII);
            Controls.Add(btnInputASCII);
            Controls.Add(btnEncode);
            Controls.Add(btnPrint);
            Controls.Add(txtResult);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtNValue);
            Controls.Add(label1);
            Controls.Add(txtInputString);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtInputString;
        private Label label1;
        private TextBox txtNValue;
        private Label label2;
        private Label label3;
        private TextBox txtResult;
        private Button btnPrint;
        private Button btnEncode;
        private Button btnInputASCII;
        private Button btnOutputASCII;
        private Button btnSort;
        private Button btnReset;
        private Button btnDecode;
        private Button btnHash;
    }
}