﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Coursework
{
    public partial class Form1 : Form
    {
        private StringProcessing? sp;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEncode_Click(object sender, EventArgs e)
        {
            try
            {
                string input = txtInputString.Text;
                int n = int.Parse(txtNValue.Text);
                sp = new StringProcessing(input, n);
                txtResult.Text = "Encoded: " + sp.Print();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (sp != null)
                txtResult.Text = sp.Print();
            else
                MessageBox.Show("Encode first!");
        }

        private void btnInputASCII_Click(object sender, EventArgs e)
        {
            if (sp != null)
                txtResult.Text = "Input ASCII: " + string.Join(", ", sp.InputCode());
            else
                MessageBox.Show("Encode first!");
        }

        private void btnOutputASCII_Click(object sender, EventArgs e)
        {
            if (sp != null)
                txtResult.Text = "Output ASCII: " + string.Join(", ", sp.OutputCode());
            else
                MessageBox.Show("Encode first!");
        }

        private void btnSort_Click(object sender, EventArgs e)
        {
            if (sp != null)
                txtResult.Text = "Sorted: " + sp.Sort();
            else
                MessageBox.Show("Enter input first!");
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtInputString.Clear();
            txtNValue.Clear();
            txtResult.Clear();
        }

        private void btnDecode_Click(object sender, EventArgs e)
        {
            if (sp != null)
            {
                sp = new StringProcessing(sp.Print(), -sp.Shift);
                txtResult.Text = "Decoded: " + sp.Print();
            }
            else
            {
                MessageBox.Show("Encode first!");
            }
        }

        private void btnHash_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtInputString.Text))
            {
                txtResult.Text = "Hashed: " + StringProcessing.ComputeHash(txtInputString.Text);
            }
            else
            {
                MessageBox.Show("Enter input first!");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
