namespace Coursework
{
    static class Program
    {
        [STAThread] // Required for Windows Forms
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1()); // Start the GUI
        }
    }
}

