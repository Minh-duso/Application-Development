﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coursework
{
    public class StringProcessing
    {
        private string _inputString = string.Empty;
        private int _shift;

        public string InputString
        {
            get => _inputString;
            set
            {
                if (string.IsNullOrEmpty(value) || !value.All(char.IsUpper) || value.Length > 40)
                    throw new ArgumentException("Input string must be uppercase letters only and max 40 characters.");
                _inputString = value;
            }
        }

        public int Shift
        {
            get => _shift;
            set
            {
                if (value < -25 || value > 25)
                    throw new ArgumentOutOfRangeException(nameof(value), "Shift must be between -25 and 25.");
                _shift = value;
            }
        }

        // Constructor with validation
        public StringProcessing(string input, int shift)
        {
            InputString = input ;
            Shift = shift;
        }

        // Encoding method (Caesar Cipher-like shift)
        public string Encode()
        {
            return new string(_inputString.Select(c =>
            {
                int shifted = c + _shift;

                // Wrap around if out of uppercase A-Z range
                if (shifted > 'Z') shifted -= 26;
                if (shifted < 'A') shifted += 26;

                return (char)shifted;
            }).ToArray());
        }

        // Decoding method (Reverses the encoding)
        public string Decode()
        {
            return new string(_inputString.Select(c =>
            {
                int shifted = c - _shift;
                if (shifted > 'Z') shifted -= 26;
                if (shifted < 'A') shifted += 26;
                return (char)shifted;
            }).ToArray());
        }

        // Method to print encoded string
        public string Print()
        {
            return Encode();
        }

        // Method to return ASCII codes of input string
        public int[] InputCode()
        {
            return _inputString.Select(c => (int)c).ToArray();
        }

        // Method to return ASCII codes of output (encoded) string
        public int[] OutputCode()
        {
            return Encode().Select(c => (int)c).ToArray();
        }

        // Sorting method
        public string Sort()
        {
            return new string(_inputString.OrderBy(c => c).ToArray());
        }
        // Hashing method (SHA-256)
        public static string ComputeHash(string input)
        {
            using (var sha256 = System.Security.Cryptography.SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(input));
                return BitConverter.ToString(bytes).Replace("-", "");
            }
        }
    }
}